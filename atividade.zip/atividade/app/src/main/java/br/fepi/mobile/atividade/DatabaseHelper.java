package br.fepi.mobile.atividade;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {


    private static final  String Database_Name = "BancoTarefas";
    private static final int Database_Version = 1;
    private static final String Tabela_Tarefas = "Tarefas";
    private static final String Coluna_ID = "id";
    private static final String Coluna_Titulo = "Titulo";
    private static final String Coluna_Descrição = "Descricao";
    private static final String Coluna_Status = "Status";

    public DatabaseHelper(Context context) {
        super(context, Database_Name, null, Database_Version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String criarTabela = "CREATE TABLE " + Tabela_Tarefas + "(" +
                Coluna_ID + "INTEGER PRYMARY KEY AUTOINCREMENT," +
                Coluna_Titulo + " TEXT, " +
                Coluna_Descrição + " TEXT," +
                Coluna_Status + " INTEGER)";
        db.execSQL(criarTabela);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + Tabela_Tarefas);
        onCreate(db);

    }

    public long adicionarTarefa(String Titulo, String Descricao, int Status){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Coluna_Titulo, Titulo);
        values.put(Coluna_Descrição, Descricao);
        values.put(Coluna_Status, Status);
        return db.insert(Tabela_Tarefas, null, values);
    }
    public int atualizarStatusTarefa(long id, int novoStatus) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(Coluna_Status, novoStatus);
        return db.update(Tabela_Tarefas, values, Coluna_ID + " = ? ", new String[]{String.valueOf(id)});

    }
    public Cursor obterTodasTarefas() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + Tabela_Tarefas, null);
    }

}
