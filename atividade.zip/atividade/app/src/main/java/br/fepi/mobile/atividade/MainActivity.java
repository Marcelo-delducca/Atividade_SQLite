package br.fepi.mobile.atividade;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        databaseHelper = new DatabaseHelper(this);

        long id = databaseHelper.adicionarTarefa("Comprar leite", "Ir ao supermercado e comprar leite", 0);
        int linhasAfetadas = databaseHelper.atualizarStatusTarefa(id, 1);
        Cursor cursor = databaseHelper.obterTodasTarefas();
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String Titulo = cursor.getString(cursor.getColumnIndex("Titulo"));
                @SuppressLint("Range") String Descricao = cursor.getString(cursor.getColumnIndex("Descricao"));
                @SuppressLint("Range") int Status = cursor.getInt(cursor.getColumnIndex("Status"));
                Log.d("BancoDados", "Tarefa: " + Titulo + ". Descrição: " + Descricao + ", Status: " + (Status == 1 ? "Concluida" : "Pendente"));

            } while (cursor.moveToNext());
        }
        cursor.close();
        }}

